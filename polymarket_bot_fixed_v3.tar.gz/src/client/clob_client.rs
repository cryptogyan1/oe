use anyhow::{anyhow, Result};
use reqwest::Client;
use serde::{Deserialize, Serialize};
use std::time::{SystemTime, UNIX_EPOCH};

use crate::wallet::signer::{ClobOrder, WalletSigner};
use ethers::types::{H256, Signature};

/// =================================================
/// Polymarket CLOB Client
/// =================================================
#[derive(Clone)]
pub struct ClobClient {
    http: Client,
    base_url: String,
    signer: WalletSigner,
    proxy_wallet: ethers::types::Address,
}

/// ---------- Orderbook Types ----------
#[derive(Debug, Deserialize)]
pub struct OrderLevel {
    pub price: String,
    pub size: String,
}

#[derive(Debug, Deserialize)]
pub struct OrderBook {
    pub bids: Vec<OrderLevel>,
    pub asks: Vec<OrderLevel>,
}

/// ---------- Signed Payload ----------
#[derive(Debug, Serialize)]
pub struct SignedOrderPayload {
    pub order: ClobOrder,
    pub signature: String,
}

impl ClobClient {
    pub fn new(
        base_url: &str,
        signer: WalletSigner,
        proxy_wallet: ethers::types::Address,
    ) -> Self {
        Self {
            http: Client::new(),
            base_url: base_url.to_string(),
            signer,
            proxy_wallet,
        }
    }

    /// ---------------------------------
    /// Fetch orderbook
    /// ---------------------------------
    pub async fn get_orderbook(&self, token_id: &str) -> Result<OrderBook> {
        let url = format!("{}/book?token_id={}", self.base_url, token_id);
        let resp = self.http.get(&url).send().await?;

        if !resp.status().is_success() {
            return Err(anyhow!("Orderbook fetch failed"));
        }

        Ok(resp.json::<OrderBook>().await?)
    }

    /// ---------------------------------
    /// Pick best price
    /// ---------------------------------
    pub fn best_price(book: &OrderBook, side: u8) -> Result<u64> {
        let level = if side == 0 {
            book.asks.first()
        } else {
            book.bids.first()
        }
        .ok_or_else(|| anyhow!("Empty orderbook"))?;

        Ok((level.price.parse::<f64>()? * 1_000_000.0) as u64)
    }

    /// ---------------------------------
    /// Submit order
    /// ---------------------------------
    pub async fn submit_order(
        &self,
        token_id: H256,
        side: u8,
        size_usdc: u64,
        price_usdc: u64,
    ) -> Result<()> {
        if size_usdc < 1 {
            return Err(anyhow!("Order size below $1 minimum"));
        }

        let order = ClobOrder::new(
            self.proxy_wallet,
            token_id,
            side,
            price_usdc,
            size_usdc,
            60, // 60s expiry
        );

        let sig: Signature = self.signer.sign_order(&order).await?;
        let payload = SignedOrderPayload {
            order,
            signature: sig.to_string(),
        };

        let url = format!("{}/order", self.base_url);
        let resp = self.http.post(&url).json(&payload).send().await?;

        let body = resp.text().await?;

        if !resp.status().is_success() {
            return Err(anyhow!("Order rejected: {}", body));
        }

        Ok(())
    }
}
