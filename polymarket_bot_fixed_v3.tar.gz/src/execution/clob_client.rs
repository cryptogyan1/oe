use anyhow::{anyhow, Result};
use ethers::prelude::*;
use ethers::types::{Address, U256};
use log::{info, warn};
use reqwest::Client;
use std::str::FromStr;
use std::sync::Arc;
use serde::{Serialize, Deserialize};
use base64::{engine::general_purpose, Engine as _};
use hmac::{Hmac, Mac};
use sha2::Sha256;
use std::time::{SystemTime, UNIX_EPOCH};

type HmacSha256 = Hmac<Sha256>;

// ==================================================
// CONSTANTS (Polygon / Polymarket)
// ==================================================

const POLYMARKET_EXCHANGE: &str = "0x4bFb41d5B3570DeFd03C39a9A4D8dE6Bd8B8982E";
const CTF_CONTRACT: &str = "0x4D97DCd97eC945f40cF65F87097ACe5EA0476045";
const USDC_ADDRESS: &str = "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174";
const MIN_ALLOWANCE: u128 = 1_000_000; // $1 (6 decimals)
const CLOB_API_URL: &str = "https://clob.polymarket.com";

// ==================================================
// CLIENT
// ==================================================

#[derive(Clone)]
pub struct ClobClient {
    pub http: Client,
    provider: Arc<SignerMiddleware<Provider<Http>, LocalWallet>>,
    proxy_wallet: Address,
    read_only: bool,
    
    // API credentials for order submission
    api_key: String,
    api_secret: String,
    api_passphrase: String,
}

impl ClobClient {
    pub async fn new(
        rpc_url: &str,
        private_key: &str,
        proxy_wallet: &str,
        api_key: String,
        api_secret: String,
        api_passphrase: String,
    ) -> Result<Self> {
        let wallet: LocalWallet = private_key.parse()?;
        let provider = Provider::<Http>::try_from(rpc_url)?;
        let chain_id = provider.get_chainid().await?.as_u64();
        let wallet = wallet.with_chain_id(chain_id);

        let signer = Arc::new(SignerMiddleware::new(provider, wallet));

        // Check for read-only mode from env
        let read_only = std::env::var("READ_ONLY")
            .unwrap_or_else(|_| "false".to_string())
            .parse()
            .unwrap_or(false);

        if read_only {
            warn!("⚠️  READ-ONLY MODE ENABLED - No real orders will be submitted");
        }

        Ok(Self {
            http: Client::new(),
            provider: signer,
            proxy_wallet: Address::from_str(proxy_wallet)?,
            read_only,
            api_key,
            api_secret,
            api_passphrase,
        })
    }

    // ==================================================
    // REQUEST SIGNING (HMAC-SHA256)
    // ==================================================
    
    fn sign_request(
        &self,
        method: &str,
        path: &str,
        body: &str,
        timestamp: &str,
    ) -> String {
        let payload = format!("{}{}{}{}", timestamp, method, path, body);

        let mut mac =
            HmacSha256::new_from_slice(self.api_secret.as_bytes())
                .expect("HMAC init failed");

        mac.update(payload.as_bytes());
        general_purpose::STANDARD.encode(mac.finalize().into_bytes())
    }

    // ==================================================
    // TRADING READINESS CHECK
    // ==================================================

    pub async fn ensure_trading_ready(&self, required_usdc: u128) -> Result<()> {
        self.ensure_balance(required_usdc).await?;

        if self.proxy_is_contract().await? {
            self.ensure_safe_checks().await?;
        } else {
            self.ensure_usdc_allowance().await?;
            self.ensure_erc1155_approval().await?;
        }

        Ok(())
    }

    async fn proxy_is_contract(&self) -> Result<bool> {
        let code = self
            .provider
            .provider()
            .get_code(self.proxy_wallet, None)
            .await?;
        Ok(!code.0.is_empty())
    }

    async fn ensure_balance(&self, required: u128) -> Result<()> {
        let bal = self.usdc().balance_of(self.proxy_wallet).call().await?;
        if bal < U256::from(required) {
            return Err(anyhow!("❌ Insufficient USDC balance. Need: {}, Have: {}", 
                required as f64 / 1_000_000.0,
                bal.as_u128() as f64 / 1_000_000.0
            ));
        }
        info!("✅ USDC balance OK: ${:.2}", bal.as_u128() as f64 / 1_000_000.0);
        Ok(())
    }

    async fn ensure_safe_checks(&self) -> Result<()> {
        let allowance = self
            .usdc()
            .allowance(self.proxy_wallet, self.exchange())
            .call()
            .await?;

        if allowance < U256::from(MIN_ALLOWANCE) {
            return Err(anyhow!("❌ USDC allowance missing on Gnosis Safe. Please approve in Polymarket UI."));
        }

        let approved = self
            .ctf()
            .is_approved_for_all(self.proxy_wallet, self.exchange())
            .call()
            .await?;

        if !approved {
            return Err(anyhow!("❌ ERC-1155 approval missing on Gnosis Safe. Please approve in Polymarket UI."));
        }

        info!("✅ Gnosis Safe approvals OK");
        Ok(())
    }

    async fn ensure_usdc_allowance(&self) -> Result<()> {
        let allowance = self
            .usdc()
            .allowance(self.proxy_wallet, self.exchange())
            .call()
            .await?;

        if allowance >= U256::from(MIN_ALLOWANCE) {
            info!("✅ USDC allowance OK");
            return Ok(());
        }

        warn!("⚠️  Approving USDC spending to Polymarket exchange...");
        let tx = self.usdc()
            .approve(self.exchange(), U256::MAX)
            .send()
            .await?
            .await?;
        
        info!("✅ USDC approved. Tx: {:?}", tx);
        Ok(())
    }

    async fn ensure_erc1155_approval(&self) -> Result<()> {
        let approved = self
            .ctf()
            .is_approved_for_all(self.proxy_wallet, self.exchange())
            .call()
            .await?;

        if approved {
            info!("✅ ERC-1155 approval OK");
            return Ok(());
        }

        warn!("⚠️  Approving ERC-1155 (CTF) to Polymarket exchange...");
        let tx = self.ctf()
            .set_approval_for_all(self.exchange(), true)
            .send()
            .await?
            .await?;
        
        info!("✅ ERC-1155 approved. Tx: {:?}", tx);
        Ok(())
    }

    // ==================================================
    // ORDER SUBMISSION - PRODUCTION READY
    // ==================================================

    pub async fn submit_order(
        &self,
        order: crate::wallet::signer::ClobOrder,
        sig: Signature,
        proxy: &str,
    ) -> Result<()> {
        if self.read_only {
            info!("📝 [READ-ONLY] Would submit order:");
            info!("   Token: 0x{}", hex::encode(order.token_id.as_bytes()));
            info!("   Side: {}", if order.side == 0 { "BUY" } else { "SELL" });
            info!("   Price: {:.6}", order.price.as_u128() as f64 / 1_000_000.0);
            info!("   Size: {:.6}", order.size.as_u128() as f64 / 1_000_000.0);
            return Ok(());
        }

        // Polymarket CLOB API order format
        #[derive(Serialize, Debug)]
        struct ClobOrderPayload {
            #[serde(rename = "tokenID")]
            token_id: String,
            
            price: String,
            size: String,
            side: String,
            
            #[serde(rename = "feeRateBps")]
            fee_rate_bps: String,
            
            nonce: String,
            expiration: String,
            
            #[serde(rename = "maker")]
            maker: String,
            
            #[serde(rename = "taker")]  
            taker: String,
            
            signature: String,
            
            #[serde(rename = "signatureType")]
            signature_type: u8,
        }

        let payload = ClobOrderPayload {
            token_id: format!("0x{}", hex::encode(order.token_id.as_bytes())),
            price: format!("{:.6}", order.price.as_u128() as f64 / 1_000_000.0),
            size: format!("{:.6}", order.size.as_u128() as f64 / 1_000_000.0),
            side: if order.side == 0 { "BUY" } else { "SELL" }.to_string(),
            fee_rate_bps: "0".to_string(), // 0 basis points = market order
            nonce: order.nonce.to_string(),
            expiration: order.expiration.to_string(),
            maker: proxy.to_string(),
            taker: "0x0000000000000000000000000000000000000000".to_string(), // Anyone can take
            signature: format!("0x{}", hex::encode(sig.to_vec())),
            signature_type: 0, // EIP-712
        };

        info!("📤 Submitting order to CLOB API...");
        info!("   Token: {}", &payload.token_id[..16]);
        info!("   {} {} @ {}", payload.side, payload.size, payload.price);

        let path = "/order";
        let url = format!("{}{}", CLOB_API_URL, path);
        let body = serde_json::to_string(&payload)?;
        
        let timestamp = SystemTime::now()
            .duration_since(UNIX_EPOCH)?
            .as_secs()
            .to_string();
        
        let signature = self.sign_request("POST", path, &body, &timestamp);
        
        let resp = self.http
            .post(&url)
            .header("POLY-API-KEY", &self.api_key)
            .header("POLY-API-SIGNATURE", signature)
            .header("POLY-API-TIMESTAMP", &timestamp)
            .header("POLY-API-PASSPHRASE", &self.api_passphrase)
            .header("Content-Type", "application/json")
            .body(body)
            .timeout(std::time::Duration::from_secs(10))
            .send()
            .await?;

        let status = resp.status();
        let body = resp.text().await?;

        if !status.is_success() {
            warn!("❌ Order rejected by CLOB API");
            warn!("   Status: {}", status);
            warn!("   Response: {}", body);
            return Err(anyhow!("Order rejected: {} - {}", status, body));
        }

        // Parse response to get order ID
        #[derive(Deserialize)]
        struct OrderResponse {
            #[serde(rename = "orderID")]
            order_id: Option<String>,
            success: Option<bool>,
        }

        match serde_json::from_str::<OrderResponse>(&body) {
            Ok(resp) => {
                if let Some(order_id) = resp.order_id {
                    info!("✅ Order submitted! ID: {}", order_id);
                } else {
                    info!("✅ Order submitted! {}", body);
                }
            }
            Err(_) => {
                info!("✅ Order submitted! {}", body);
            }
        }

        Ok(())
    }

    // ==================================================
    // STUBS FOR FUTURE
    // ==================================================

    pub async fn get_orderbook(&self, _token_id: &str) -> Result<()> {
        Err(anyhow!("Use execution::orderbook::fetch_orderbook instead"))
    }

    pub fn best_price(&self, _book: &(), _side: u8) -> Result<()> {
        Err(anyhow!("Use execution::orderbook methods instead"))
    }

    // ==================================================
    // BALANCE QUERY
    // ==================================================
    
    /// Get USDC balance from blockchain
    pub async fn get_usdc_balance(&self) -> Result<rust_decimal::Decimal> {
        let balance_wei = self.usdc()
            .balance_of(self.proxy_wallet)
            .call()
            .await?;
        
        // Convert from wei (6 decimals for USDC) to decimal
        let balance_u128 = balance_wei.as_u128();
        let balance_decimal = rust_decimal::Decimal::from(balance_u128) 
            / rust_decimal::Decimal::from(1_000_000);
        
        Ok(balance_decimal)
    }

    // ==================================================
    // CONTRACT HELPERS
    // ==================================================

    fn exchange(&self) -> Address {
        Address::from_str(POLYMARKET_EXCHANGE).unwrap()
    }

    fn usdc(&self) -> USDCContract<SignerMiddleware<Provider<Http>, LocalWallet>> {
        USDCContract::new(
            Address::from_str(USDC_ADDRESS).unwrap(),
            self.provider.clone(),
        )
    }

    fn ctf(&self) -> CTFContract<SignerMiddleware<Provider<Http>, LocalWallet>> {
        CTFContract::new(
            Address::from_str(CTF_CONTRACT).unwrap(),
            self.provider.clone(),
        )
    }
}

// ==================================================
// ABI GENERATION
// ==================================================

abigen!(
    USDCContract,
    r#"[
        function balanceOf(address) view returns (uint256)
        function allowance(address,address) view returns (uint256)
        function approve(address,uint256) returns (bool)
    ]"#
);

abigen!(
    CTFContract,
    r#"[
        function isApprovedForAll(address,address) view returns (bool)
        function setApprovalForAll(address,bool)
    ]"#
);
